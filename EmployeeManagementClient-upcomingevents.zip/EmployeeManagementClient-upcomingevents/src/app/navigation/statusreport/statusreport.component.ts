import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-statusreport',
  templateUrl: './statusreport.component.html',
  styleUrls: ['./statusreport.component.css']
})
export class StatusreportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
