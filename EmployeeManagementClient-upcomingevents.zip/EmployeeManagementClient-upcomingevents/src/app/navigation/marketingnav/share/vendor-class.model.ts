export class VendorClass {
    date: Date;
    vendorOrganization: string;
    vendorContactName: string;
    phone: number;
    contactEmail: string;
    implementationPartner: string;
    status: string;
    client: string;
    comments: string;
}
