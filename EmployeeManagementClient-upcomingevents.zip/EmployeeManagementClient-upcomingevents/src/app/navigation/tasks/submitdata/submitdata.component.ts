import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-submitdata',
  templateUrl: './submitdata.component.html',
  styleUrls: ['./submitdata.component.css']
})
export class SubmitdataComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
